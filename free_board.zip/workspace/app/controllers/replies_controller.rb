class RepliesController < ApplicationController
    def create
        reply = Reply.create!(post_id: params[:post_id], content: params[:content])
        redirect_to "/read/#{reply.post_id}"
    end
    
    def delete
        reply = Reply.find(params[:reply_id])
        reply.destroy
        
        redirect_to "/read/#{params[:post_id]}"
    end
end
