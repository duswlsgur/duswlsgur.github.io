class Reply < ApplicationRecord
    belongs_to :post
end
