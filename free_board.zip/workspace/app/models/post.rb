class Post < ApplicationRecord
    has_many :replies
end
