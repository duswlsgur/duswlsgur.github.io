Rails.application.routes.draw do
  root 'home#index'

  get 'new' => 'post#create'

  get 'read/:post_id' => 'post#read'

  get 'edit/:post_id' => 'post#update'

  post 'post/create_post'

  post 'post/update_post/:post_id' => 'post#update_post'

  post 'post/delete_post/:post_id' => 'post#delete_post'
  
  post 'replies/create/:post_id' => 'replies#create'
  
  post 'replies/delete/:post_id/:reply_id' => 'replies#delete'
  
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
