# likelion-5th

멋쟁이 사자처럼 5기 광운대학교 강의 프로젝트

```
git clone https://github.com/likelionKW/likelion-5th.git
cd likelion-5th
bundle install
rake db:migrate
rails s
```
